import React, { useEffect } from 'react'
import { dndListServices, dndDetailServices } from '@/services'
import { useForm } from 'react-hook-form'
import { useDndListStore } from '@/store/dndList'
import { key } from 'localforage'


const useDndCard = () => {



    return {

    }
}

export { useDndCard }